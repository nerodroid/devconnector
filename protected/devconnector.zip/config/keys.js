module.exports = {
    mongoURI: 'mongodb+srv://nerodroid:0714076576@cluster0.w54fe.mongodb.net/devconnector?retryWrites=true&w=majority',
    secretOrKey: 'secret'

};
